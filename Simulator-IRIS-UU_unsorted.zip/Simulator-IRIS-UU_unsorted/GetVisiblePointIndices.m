function visible_points = GetVisiblePointIndices(CameraPos,Psi,CameraAngleTheta,FOV,MinDOF,MaxDOF);

%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here



end

