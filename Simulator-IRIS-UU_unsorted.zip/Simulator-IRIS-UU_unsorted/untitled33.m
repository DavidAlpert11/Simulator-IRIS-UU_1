clc
clear
close all
temp = importdata("C:\Users\HomePc\Downloads\new 1.txt");
data = temp.data;

data_regular = zeros(1,size(data,2));
data_optimization = zeros(1,size(data,2));

for i=1:1:size(data,2)
    if (data(i,1)==0)
        data_regular(i,:) = zeros(size(data,2),1);
    else
        data_optimization(i,:) = zeros(size(data,2),1);
    end
end
figure;
grid on; grid minor; hold on; box on;
plot(data_regular())
