clc
clear
close all


figure('name','Quadrotor AUS','numbertitle','off','color','w','units','normalized','position',[0 0 1 1]);
hold on; grid on; box on;
xlabel('x[m]','Fontsize',25)
ylabel('y[m]','Fontsize',25)
zlabel('z[m]','Fontsize',25)

LoadDataForMovie;

ShowInitStage;
