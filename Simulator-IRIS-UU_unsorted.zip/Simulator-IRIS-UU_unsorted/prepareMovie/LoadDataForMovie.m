
Environment = GetEnvironmentMission('\\wsl.localhost\Ubuntu\home\davidalpert11\Projects\IRIS-UU\data\bridge\bridge.obj');

%%
 %load
    folder = ['\\wsl.localhost\Ubuntu\home\davidalpert11\Projects\IRIS-UU\build\Results\run_test_12032024_test_col_1_9\Run', num2str(numOfRun)];
    load([folder,'\UAVSimulationResults.mat'])

    vertex = readtable([folder,'\testIRIS_vertex']);
    all_poi_indexes  = extractUniquePOI(vertex);
    edge = importdata([folder,'\testIRIS_edge']);
    configuration = importdata([folder,'\testIRIS_conf']);

    aa = 1:1:length(edge);
    soucre = configuration(edge(aa,1)+1,1:3);
    target = configuration(edge(aa,2)+1,1:3);

    dt = 0.01;
    t=[1:1:length(RecordState.X(1,:))]*dt;
    time =t;

    [POIInspectedCell,collisionCheck] = GetInspectedPOIandCollision(folder);

    %%

