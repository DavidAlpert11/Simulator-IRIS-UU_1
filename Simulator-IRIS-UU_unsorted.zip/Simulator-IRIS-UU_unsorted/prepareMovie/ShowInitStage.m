%% show bridge
% Define custom colormap for the bridge structure
    numColors = 256; % Number of colors in the colormap
    brownColor = [0.5 0.25 0]; % Brown color for the bridge structure
    grayColor = [0.5 0.5 0.5]; % Gray color for the bridge structure
    greenColor = [0 0.5 0]; % Green color for the bridge structure

    % Create custom colormap with smooth transition between colors
    customColorMap = zeros(numColors, 3);
    for i = 1:3
        customColorMap(:, i) = [linspace(brownColor(i), grayColor(i), numColors/2), ...
            linspace(grayColor(i), greenColor(i), numColors/2)].';
    end

    % Plot the bridge with realistic colors
    h1 = patch('vertices', [Environment.obj.v(:,1),Environment.obj.v(:,2),Environment.obj.v(:,3)], 'faces', Environment.obj.f.v, ...
        'FaceVertexCData', Environment.obj.v(:,3), 'FaceColor', 'interp', 'EdgeColor', 'none');

    % Apply custom colormap to the bridge structure
    colormap(customColorMap);

    % Adjust transparency and lighting
    shading interp
    lighting gouraud
    light('Position',[1 0 1]);
    material shiny
    alpha(.3)  % Adjust transparency