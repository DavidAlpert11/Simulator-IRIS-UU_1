% Function to plot the drone's trajectory
function plot_drone_trajectory(RecordState, index)
    % Your plotting code here
end