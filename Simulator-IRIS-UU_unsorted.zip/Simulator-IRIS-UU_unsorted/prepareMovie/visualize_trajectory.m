% Main function to visualize the drone trajectory beside a bridge
function visualize_trajectory(time, RecordState, Command, Environment, collisionCheck)
    % Initialize variables
    totalPOI = [];
    totalPlanedPOI = [];
    NumberOfCollision = 0;
    lastIndex = 1;
    indexInspectedPOI = 1;

    % Create a figure
    figure;
    hold on;
    grid on;
    xlabel('X');
    ylabel('Y');
    zlabel('Z');
    title('Drone Trajectory Beside Bridge');

    % Main loop to plot the trajectory and adjust view
    for i = 1:length(time)
        % Plot the drone's trajectory
        plot_drone_trajectory(RecordState, i);
        
        % Adjust view based on drone's position
        adjust_view(RecordState, i);

        % Update inspected POIs and collisions
        update_inspected_POIs_and_collisions();

        % Handle video creation
        create_video_if_needed(i);
        
        % Draw now
        drawnow limitrate;
    end
end







