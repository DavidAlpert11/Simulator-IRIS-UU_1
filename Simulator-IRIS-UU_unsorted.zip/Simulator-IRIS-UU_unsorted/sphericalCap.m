function [V]= sphericalCap(R,h)
    V = 1/3*pi*h^2*(3*R-h);
end


