       currentIndexesPOI = 1;     
totalPOI = currentIndexesPOI;

for indexInspectedPOI=1:1:length(POIInspectedCell)         
currentIndexesPOI = POIInspectedCell{indexInspectedPOI}+1;
                totalPOI = [totalPOI,currentIndexesPOI];
                num2str(length(unique(totalPOI)))
end