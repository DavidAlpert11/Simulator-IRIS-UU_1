function CameraParameter = InitCamera
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
CameraParameter.FOV = 94*pi/180;%[rad]
CameraParameter.MinDOF = 0.2;%[m]
CameraParameter.MaxDOF = 10;%[m]
end

