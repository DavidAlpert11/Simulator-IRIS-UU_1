% InitScenario;
% InitIMU;
% InitState;
% InitNavState;
% InitEKF;
% InitDynamic;
% GetSensorMeas;
% UpdateNavDynamic;
% UpdateTrueIMUBias;
% InitQuad;
a=1;
disp(a)